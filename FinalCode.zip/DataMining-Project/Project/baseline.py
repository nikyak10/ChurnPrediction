import pandas as pd
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# dataset
telco = pd.read_csv('data/telco.csv')

# select columns
telco = telco[['Satisfaction Score', 'Churn Label']]

# encoding
telco['Churn Label'] = telco['Churn Label'].replace({'Yes': 1, 'No': 0})

# predict churn if Satisfaction Score < 3
telco['Predicted Churn'] = (telco['Satisfaction Score'] < 3).astype(int)

# evaluation
y_true = telco['Churn Label']
y_pred = telco['Predicted Churn']

print(telco['Predicted Churn'])
print(telco['Churn Label'])

print("Classification Report:")
print(classification_report(y_true, y_pred))

# confusion matrix
cm = confusion_matrix(y_true, y_pred)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=['No Churn', 'Churn'], yticklabels=['No Churn', 'Churn'])
plt.title('Confusion Matrix: Baseline Model')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()
