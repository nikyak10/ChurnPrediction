from sklearn import preprocessing
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score, RandomizedSearchCV, train_test_split
from sklearn.metrics import accuracy_score, make_scorer, classification_report, confusion_matrix, recall_score
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import uniform, randint
import numpy as np

# load data
telco = pd.read_csv('data/telco.csv')
telco_preprocessed = telco.copy()

# replace 'None' in 'Internet Type'
telco_preprocessed['Internet Type'] = telco_preprocessed['Internet Type'].fillna('No Internet')

# create boolean columns
telco_preprocessed['Has Extra Data Charges'] = telco_preprocessed['Total Extra Data Charges'] > 0
telco_preprocessed['Has Refunds'] = telco_preprocessed['Total Refunds'] > 0

# drop original columns
telco_preprocessed = telco_preprocessed.drop(columns=['Total Extra Data Charges', 'Total Refunds'])

# drop redundant or unimportant features
telco_preprocessed = telco_preprocessed.drop(columns=['Customer ID', 'Quarter', 'Under 30', 'Senior Citizen',
                                                      'State', 'Country', 'Churn Score', 'Churn Category',
                                                      'Churn Reason', 'Customer Status', 'Zip Code',
                                                      'City', 'Offer', 'Referred a Friend', 'Internet Service'])
cols = [col for col in telco_preprocessed.columns if telco_preprocessed[col].nunique() == 1]
telco_preprocessed = telco_preprocessed.drop(columns=cols)

# handle binary categorical features
for col in telco_preprocessed.columns:
    telco_preprocessed[col] = telco_preprocessed[col].replace({'Yes': 1, 'No': 0})
    telco_preprocessed[col] = telco_preprocessed[col].replace({'Male': 1, 'Female': 0})

# encode non-numeric features
encoder = preprocessing.OneHotEncoder()
encoded = pd.DataFrame(encoder.fit_transform(telco_preprocessed[['Internet Type', 'Contract', 'Payment Method']]).toarray(),
                       columns=encoder.get_feature_names_out(['Internet Type', 'Contract', 'Payment Method']))
telco_preprocessed = telco_preprocessed.drop(columns=['Internet Type', 'Contract', 'Payment Method'])
telco_preprocessed = telco_preprocessed.join(encoded)

# split features and labels
X = telco_preprocessed.drop(columns=['Churn Label'])
label = telco_preprocessed['Churn Label']

# train-test split
X_train, X_test, y_train, y_test = train_test_split(X, label, test_size=0.2, random_state=0, stratify=label)

# define scoring
accuracy_scorer = make_scorer(accuracy_score)
recall_scorer = make_scorer(recall_score, pos_label=1)

# define parameter grids
dt_param_grid = {
    'criterion': ['gini', 'entropy'],
    'min_impurity_decrease': uniform(0.0, 0.05),
    'max_depth': randint(2, 20)
}

rf_param_grid = {
    'n_estimators': randint(10, 100),
    'criterion': ['gini', 'entropy'],
    'min_impurity_decrease': uniform(0.0, 0.05),
    'max_depth': randint(2, 20)
}

# outer CV for nested cross-validation
outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

# nested CV for decision tree
dt_model = DecisionTreeClassifier(random_state=0)
dt_random_search = RandomizedSearchCV(
    estimator=dt_model,
    param_distributions=dt_param_grid,
    n_iter=50,
    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=0),  # inner CV
    scoring=accuracy_scorer,  # use recall_scorer for recall metric
    n_jobs=-1,
    random_state=0
)

dt_nested_scores = cross_val_score(dt_random_search, X, label, cv=outer_cv, scoring=accuracy_scorer, n_jobs=-1)
print(f"Decision Tree Nested CV Accuracy: {np.mean(dt_nested_scores):.4f} ± {np.std(dt_nested_scores):.4f}")

# nested CV for random forest
rf_model = RandomForestClassifier(random_state=0)
rf_random_search = RandomizedSearchCV(
    estimator=rf_model,
    param_distributions=rf_param_grid,
    n_iter=50,
    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=0),  # inner CV
    scoring=accuracy_scorer,  # use recall_scorer for recall metric
    n_jobs=-1,
    random_state=0
)

rf_nested_scores = cross_val_score(rf_random_search, X, label, cv=outer_cv, scoring=accuracy_scorer, n_jobs=-1)
print(f"Random Forest Nested CV Accuracy: {np.mean(rf_nested_scores):.4f} ± {np.std(rf_nested_scores):.4f}")

# fit RandomizedSearchCV for evaluation
dt_random_search.fit(X_train, y_train)
rf_random_search.fit(X_train, y_train)

# print best parameters and scores
print(f"Decision Tree Best Parameters: {dt_random_search.best_params_}")
print(f"Decision Tree Best Accuracy: {dt_random_search.best_score_:.4f}")

print(f"Random Forest Best Parameters: {rf_random_search.best_params_}")
print(f"Random Forest Best Accuracy: {rf_random_search.best_score_:.4f}")

# evaluate decision tree on test set
dt_best_model = dt_random_search.best_estimator_
y_pred_dt = dt_best_model.predict(X_test)

cm_dt = confusion_matrix(y_test, y_pred_dt)
cr_dt = classification_report(y_test, y_pred_dt)
print("Decision Tree Classification Report:")
print(cr_dt)

plt.figure(figsize=(8, 6))
sns.heatmap(cm_dt, annot=True, fmt="d", cmap="Blues",
            xticklabels=['Predicted Negative', 'Predicted Positive'],
            yticklabels=['Actual Negative', 'Actual Positive'])
plt.title('Confusion Matrix for Decision Tree')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()

# evaluate random forest on test set
rf_best_model = rf_random_search.best_estimator_
y_pred_rf = rf_best_model.predict(X_test)

cm_rf = confusion_matrix(y_test, y_pred_rf)
cr_rf = classification_report(y_test, y_pred_rf)
print("Random Forest Classification Report:")
print(cr_rf)

plt.figure(figsize=(8, 6))
sns.heatmap(cm_rf, annot=True, fmt="d", cmap="Oranges",
            xticklabels=['Predicted Negative', 'Predicted Positive'],
            yticklabels=['Actual Negative', 'Actual Positive'])
plt.title('Confusion Matrix for Random Forest')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()
