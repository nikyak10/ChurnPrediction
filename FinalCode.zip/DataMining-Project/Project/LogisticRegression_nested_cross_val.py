from sklearn import preprocessing
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, RandomizedSearchCV, cross_val_score, StratifiedKFold
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import confusion_matrix, classification_report, make_scorer, recall_score
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import uniform, randint
import numpy as np

# load data
telco = pd.read_csv('data/telco.csv')
telco_preprocessed = telco.copy()

# replace 'None' in 'Internet Type'
telco_preprocessed['Internet Type'] = telco_preprocessed['Internet Type'].fillna('No Internet')

# create boolean columns
telco_preprocessed['Has Extra Data Charges'] = telco_preprocessed['Total Extra Data Charges'] > 0
telco_preprocessed['Has Refunds'] = telco_preprocessed['Total Refunds'] > 0

# drop original columns
telco_preprocessed = telco_preprocessed.drop(columns=['Total Extra Data Charges', 'Total Refunds'])

# drop redundant or unimportant features
telco_preprocessed = telco_preprocessed.drop(columns=['Customer ID', 'Quarter', 'Under 30', 'Senior Citizen',
                                                      'State', 'Country', 'Churn Score', 'Churn Category',
                                                      'Churn Reason', 'Customer Status', 'Zip Code',
                                                      'City', 'Offer', 'Referred a Friend', 'Internet Service'])
cols = [col for col in telco_preprocessed.columns if telco_preprocessed[col].nunique() == 1]
telco_preprocessed = telco_preprocessed.drop(columns=cols)

# handle binary categorical features
for col in telco_preprocessed.columns:
    telco_preprocessed[col] = telco_preprocessed[col].replace({'Yes': 1, 'No': 0})
    telco_preprocessed[col] = telco_preprocessed[col].replace({'Male': 1, 'Female': 0})

# encode non-numeric features
encoder = preprocessing.OneHotEncoder()
encoded = pd.DataFrame(encoder.fit_transform(telco_preprocessed[['Internet Type', 'Contract', 'Payment Method']]).toarray(),
                       columns=encoder.get_feature_names_out(['Internet Type', 'Contract', 'Payment Method']))
telco_preprocessed = telco_preprocessed.drop(columns=['Internet Type', 'Contract', 'Payment Method'])
telco_preprocessed = telco_preprocessed.join(encoded)

# split features and labels
X = telco_preprocessed.drop(columns=['Churn Label'])
label = telco_preprocessed['Churn Label']

# train-test split
X_train, X_test, y_train, y_test = train_test_split(X, label, test_size=0.2, random_state=0, stratify=label)

# scale features
scaler_minmax = MinMaxScaler()
X_train_scaled = scaler_minmax.fit_transform(X_train)
X_test_scaled = scaler_minmax.transform(X_test)

# nested cross-validation with random search
model = LogisticRegression(random_state=0)

# define parameter grid
param_distributions = {
    'penalty': ['l2'],  # L2 regularization
    'C': uniform(0.01, 10),  # regularization strength
    'solver': ['lbfgs', 'liblinear'],  # solvers for logistic regression
    'max_iter': randint(100, 5000)  # max iterations
}

# inner CV for hyperparameter tuning
inner_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

# custom scoring for recall
recall_scorer = make_scorer(recall_score, pos_label=1)

# random search with inner CV
random_search = RandomizedSearchCV(
    model,
    param_distributions=param_distributions,
    n_iter=50,  # number of random combinations
    cv=inner_cv,
    scoring='accuracy',  # use recall_scorer for recall
    n_jobs=-1,  # use all cores
    random_state=0
)

# outer CV for evaluation
outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

# nested CV
nested_scores = cross_val_score(random_search, X_train_scaled, y_train, cv=outer_cv, scoring='accuracy', n_jobs=-1)

# fit random search on training set
random_search.fit(X_train_scaled, y_train)

# output results
print(f"Nested cross-validation accuracy: {np.mean(nested_scores):.4f} ± {np.std(nested_scores):.4f}")
print(f"Best parameters found: {random_search.best_params_}")
print(f"Best cross-validation score: {random_search.best_score_:.4f}")

# train final model with best params
final_model = LogisticRegression(**random_search.best_params_, random_state=0)
final_model.fit(X_train_scaled, y_train)

# predict on test set
y_pred = final_model.predict(X_test_scaled)

# classification report and confusion matrix
print(classification_report(y_test, y_pred))
cm = confusion_matrix(y_test, y_pred)

# visualize confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Oranges",
            xticklabels=['Predicted Negative', 'Predicted Positive'],
            yticklabels=['Actual Negative', 'Actual Positive'])
plt.title('Confusion Matrix for Logistic Regression')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()
