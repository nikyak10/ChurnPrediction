from sklearn import preprocessing
import pandas as pd
from sklearn.model_selection import train_test_split, RandomizedSearchCV, cross_val_score, StratifiedKFold
from sklearn.naive_bayes import MultinomialNB, GaussianNB
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import confusion_matrix, classification_report, make_scorer, recall_score
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import uniform
import numpy as np

# load and preprocess data
telco = pd.read_csv('data/telco.csv')
telco_preprocessed = telco.copy()

# replace 'None' in 'Internet Type'
telco_preprocessed['Internet Type'] = telco_preprocessed['Internet Type'].fillna('No Internet')

# create boolean columns
telco_preprocessed['Has Extra Data Charges'] = telco_preprocessed['Total Extra Data Charges'] > 0
telco_preprocessed['Has Refunds'] = telco_preprocessed['Total Refunds'] > 0

# drop original columns
telco_preprocessed = telco_preprocessed.drop(columns=['Total Extra Data Charges', 'Total Refunds'])

# drop redundant or unimportant features
telco_preprocessed = telco_preprocessed.drop(columns=['Customer ID', 'Quarter', 'Under 30', 'Senior Citizen',
                                                      'State', 'Country', 'Churn Score', 'Churn Category',
                                                      'Churn Reason', 'Customer Status', 'Zip Code',
                                                      'City', 'Offer', 'Referred a Friend', 'Internet Service'])
cols = [col for col in telco_preprocessed.columns if telco_preprocessed[col].nunique() == 1]
telco_preprocessed = telco_preprocessed.drop(columns=cols)

# encode binary categorical features
for col in telco_preprocessed.columns:
    telco_preprocessed[col] = telco_preprocessed[col].replace({'Yes': 1, 'No': 0})
    telco_preprocessed[col] = telco_preprocessed[col].replace({'Male': 1, 'Female': 0})

# select numerical features
numeric_cols = telco_preprocessed.select_dtypes(include='number')
labels = numeric_cols['Churn Label']
X = numeric_cols.drop(columns=['Churn Label'])

# train-test split
X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2, random_state=42)

# normalize features
scaler_minmax = MinMaxScaler()
X = scaler_minmax.fit_transform(X)
X_train = scaler_minmax.fit_transform(X_train)
X_test = scaler_minmax.fit_transform(X_test)

# nested cross-validation setup
outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
inner_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# custom scoring for recall
recall_scorer = make_scorer(recall_score, pos_label=1)

# parameter grid for MultinomialNB
multinomial_param_grid = {
    'alpha': uniform(0.01, 1.0)  # smoothing parameter
}

# RandomizedSearchCV for MultinomialNB
multinomial_model = RandomizedSearchCV(
    MultinomialNB(),
    param_distributions=multinomial_param_grid,
    n_iter=50,
    cv=inner_cv,
    scoring='accuracy',  # use recall_scorer for recall
    random_state=42,
    n_jobs=-1
)

# GaussianNB model
gaussian_model = GaussianNB()

# nested CV for MultinomialNB
multinomial_scores = cross_val_score(multinomial_model, X, labels, cv=outer_cv, scoring='accuracy', n_jobs=-1)
print(f"MultinomialNB Nested CV Accuracy: {np.mean(multinomial_scores):.4f} ± {np.std(multinomial_scores):.4f}")

# nested CV for GaussianNB
gaussian_scores = cross_val_score(gaussian_model, X, labels, cv=outer_cv, scoring='accuracy', n_jobs=-1)
print(f"GaussianNB Nested CV Accuracy: {np.mean(gaussian_scores):.4f} ± {np.std(gaussian_scores):.4f}")

# fit MultinomialNB on training set
multinomial_model.fit(X_train, y_train)
print(f"MultinomialNB Best Parameters: {multinomial_model.best_params_}")
print(f"MultinomialNB Best CV Score: {multinomial_model.best_score_:.4f}")
y_pred_multinomial = multinomial_model.predict(X_test)

# fit GaussianNB on training set
gaussian_model.fit(X_train, y_train)
y_pred_gaussian = gaussian_model.predict(X_test)

# confusion matrix and report for MultinomialNB
cm_multinomial = confusion_matrix(y_test, y_pred_multinomial)
cr_multinomial = classification_report(y_test, y_pred_multinomial)
print("MultinomialNB Classification Report:")
print(cr_multinomial)

plt.figure(figsize=(8, 6))
sns.heatmap(cm_multinomial, annot=True, fmt="d", cmap="Blues",
            xticklabels=['Predicted Negative', 'Predicted Positive'],
            yticklabels=['Actual Negative', 'Actual Positive'])
plt.title('Confusion Matrix for MultinomialNB')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()

# confusion matrix and report for GaussianNB
cm_gaussian = confusion_matrix(y_test, y_pred_gaussian)
cr_gaussian = classification_report(y_test, y_pred_gaussian)
print("GaussianNB Classification Report:")
print(cr_gaussian)

plt.figure(figsize=(8, 6))
sns.heatmap(cm_gaussian, annot=True, fmt="d", cmap="Oranges",
            xticklabels=['Predicted Negative', 'Predicted Positive'],
            yticklabels=['Actual Negative', 'Actual Positive'])
plt.title('Confusion Matrix for GaussianNB')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()
