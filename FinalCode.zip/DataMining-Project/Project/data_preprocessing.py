from sklearn import preprocessing
import pandas as pd
from sklearn.model_selection import train_test_split
from unicodedata import numeric
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import MinMaxScaler, StandardScaler

from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt

telco = pd.read_csv('data/telco.csv')
telco_preprocessed = telco.copy()

# delete some features which are the same for every sample and some features which are not important
telco_preprocessed = telco.drop(columns=['Customer ID', 'Quarter', 'Under 30', 'Senior Citizen',
                                         'State', 'Country', 'Churn Score', 'CLTV', 'Churn Category',
                                         'Churn Reason', 'Customer Status', 'Zip Code', 'Latitude', 'Longitude',
                                         'Churn Reason','City'])
cols = []
for i in telco_preprocessed.columns:
    if telco_preprocessed[i].nunique() == 1:
        cols.append(i)
telco_preprocessed = telco_preprocessed.drop(columns=cols)

print(telco_preprocessed.head())

# handling with those features with two categories, that are yes or no

cat = telco_preprocessed.select_dtypes(include='object')
bin_cols = []
for i in cat.columns:
    if cat[i].nunique() == 2:
        bin_cols.append(i)
print(bin_cols)
bin_cols.remove('Gender')
print(bin_cols)
for i in telco_preprocessed.columns:
    telco_preprocessed[i] = telco_preprocessed[i].replace({'Yes': 1, 'No': 0})
    telco_preprocessed[i] = telco_preprocessed[i].replace({'Male': 1, 'Female': 0})
print(telco_preprocessed.columns)

# currently selecting numerical features
numeric_cols = telco_preprocessed.select_dtypes(include='number')
print(numeric_cols.head())
print(numeric_cols.columns)
labels = numeric_cols['Churn Label']
X = numeric_cols.drop(columns=['Churn Label'])

# showing the feature vector
print(X.columns)

# begin fitting Naive-Bayes model

# normalizing the X dataset
scaler_minmax = MinMaxScaler()
X = scaler_minmax.fit_transform(X)
print(X)
'''
'Gender', 'Age', 'Married', 'Dependents', 'Number of Dependents',
       'Population', 'Referred a Friend', 'Number of Referrals',
       'Tenure in Months', 'Phone Service',
       'Avg Monthly Long Distance Charges', 'Multiple Lines',
       'Internet Service', 'Avg Monthly GB Download', 'Online Security',
       'Online Backup', 'Device Protection Plan', 'Premium Tech Support',
       'Streaming TV', 'Streaming Movies', 'Streaming Music', 'Unlimited Data',
       'Paperless Billing', 'Monthly Charge', 'Total Charges', 'Total Refunds',
       'Total Extra Data Charges', 'Total Long Distance Charges',
       'Total Revenue', 'Satisfaction Score'
'''
