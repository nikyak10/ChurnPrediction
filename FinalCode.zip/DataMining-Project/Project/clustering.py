
from sklearn import preprocessing, __all__
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from unicodedata import numeric
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt

from data_preprocessing import scaler_minmax

telco = pd.read_csv('data/telco.csv')
telco_preprocessed = telco.copy()

# delete some features which are the same for every sample and some features which are not important
telco_preprocessed = telco.drop(columns=['Customer ID', 'Quarter', 'Under 30', 'Senior Citizen',
                                         'State', 'Country', 'Churn Score', 'CLTV', 'Churn Category',
                                         'Churn Reason', 'Customer Status', 'Zip Code', 'Latitude', 'Longitude',
                                         'Churn Reason', 'City', 'Offer'])
cols = []
for i in telco_preprocessed.columns:
    if telco_preprocessed[i].nunique() == 1:
        cols.append(i)
telco_preprocessed = telco_preprocessed.drop(columns=cols)

print(telco_preprocessed.head())

# handling with those features with two categories, that are yes or no

cat = telco_preprocessed.select_dtypes(include='object')
bin_cols = []
for i in cat.columns:
    if cat[i].nunique() == 2:
        bin_cols.append(i)

bin_cols.remove('Gender')
print(bin_cols)
for i in telco_preprocessed.columns:
    telco_preprocessed[i] = telco_preprocessed[i].replace({'Yes': 1, 'No': 0})
    telco_preprocessed[i] = telco_preprocessed[i].replace({'Male': 1, 'Female': 0})
head = telco_preprocessed.head()
for i in head.iterrows():
    print(i)
    break
print(telco_preprocessed.head)
# showing the first data
'''
 Gender                                             1
Age                                               78
Married                                            0
Dependents                                         0
Number of Dependents                               0
Population                                     68701
Referred a Friend                                  0
Number of Referrals                                0
Tenure in Months                                   1
Offer                                           None
Phone Service                                      0
Avg Monthly Long Distance Charges                0.0
Multiple Lines                                     0
Internet Service                                   1
Internet Type                                    DSL
Avg Monthly GB Download                            8
Online Security                                    0
Online Backup                                      0
Device Protection Plan                             1
Premium Tech Support                               0
Streaming TV                                       0
Streaming Movies                                   1
Streaming Music                                    0
Unlimited Data                                     0
Contract                              Month-to-Month
Paperless Billing                                  1
Payment Method                       Bank Withdrawal
Monthly Charge                                 39.65
Total Charges                                  39.65
Total Refunds                                    0.0
Total Extra Data Charges                          20
Total Long Distance Charges                      0.0
Total Revenue                                  59.65
Satisfaction Score                                 3
Churn Label                                        1
'''

# encode the non-numeric features, that are  'Offer','Internet Type','Contract','Payment Method'
encoder = preprocessing.OneHotEncoder()
encoded = pd.DataFrame(encoder.fit_transform(telco_preprocessed
                                             [['Internet Type', 'Contract', 'Payment Method']]).toarray(),
                       columns=encoder.get_feature_names_out(['Internet Type', 'Contract', 'Payment Method']))
telco_preprocessed = telco_preprocessed.drop(columns=['Internet Type', 'Contract', 'Payment Method'])
telco_preprocessed = telco_preprocessed.join(encoded)

print(telco_preprocessed.head())

# normalizing the dataset using the MinMax method
original_columns = telco_preprocessed.columns
scaler_minmax = MinMaxScaler()
telco_preprocessed = scaler_minmax.fit_transform(telco_preprocessed)
telco_preprocessed = pd.DataFrame(telco_preprocessed, columns=original_columns)
print(telco_preprocessed.head())

# decomposing the dataset by using PCA method
from sklearn.decomposition import PCA

pca = PCA(n_components=8, random_state=42)

x = pd.DataFrame(pca.fit_transform(telco_preprocessed), columns=['PC' + str(i) for i in range(1, 9)])
print(x.head())

# calculating the wcss(within cluster sum of square errors)
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

max_range = 7
wcss = []
for k in range(2, max_range):
    kmeans = KMeans(n_clusters=k, random_state=42)
    model = kmeans.fit(x)
    wcss.append(model.inertia_)
print(wcss)

# visualizing the wcss
plt.plot(range(2, max_range), wcss)
plt.title('wcss')
plt.xlabel('number of clusters')
plt.ylabel('Wcss Score')
plt.grid()
plt.show()

# calculating the silhouette score
scores = []
for k in range(2, max_range):
    kmeans = KMeans(n_clusters=k, random_state=42)
    labels = kmeans.fit_predict(x)
    score = silhouette_score(x, labels)
    scores.append(score)
# visualizing the two figures
plt.subplot(2, 1, 1)
plt.plot(range(2, max_range), wcss)
plt.title('wcss')
plt.xlabel('Number of clusters')
plt.ylabel('Wcss Score')
plt.grid()
plt.subplot(2, 1, 2)
plt.plot(range(2, max_range), scores)
plt.title('silhouette')
plt.xlabel('Number of clusters')
plt.ylabel('silhouette Score')
plt.grid()

plt.tight_layout()
plt.show()

# clustering by using hierarchy algorithm
from scipy.cluster.hierarchy import dendrogram, linkage

linkage_matrix = linkage(x, method='ward')
# visualizing the result
dendrogram(linkage_matrix)
plt.title('Hierarchical Clustering Dendrogram')
plt.xlabel('Sample Index')
plt.ylabel('Distance')
plt.show()

# clustering by using kmeans algorithm and visualizing the result
kmeans = KMeans(n_clusters=3, random_state=42)
model = kmeans.fit(x)
print(model.labels_)
x['clusters'] = pd.Series(model.labels_)
print(x.head())
print(x.shape)
sns.pairplot(x, hue='clusters')
plt.show()

# the clustering analysis
# df_analysis=pd.read_csv('data/telco.csv')
# df_analysis['clusters']=pd.Series(model.labels_)

telco_preprocessed['clusters'] = pd.Series(model.labels_)

df_analysis = telco_preprocessed
# analyzing the importance of some features in different clusters


print(df_analysis[df_analysis['clusters'] == 0.0])

print(df_analysis[(df_analysis['clusters'] == 0.0) & (df_analysis['Contract_Month-to-Month'] == 1)].shape[0])
print(df_analysis[(df_analysis['clusters'] == 1.0) & (df_analysis['Contract_Month-to-Month'] == 1)].shape[0])
print(df_analysis[(df_analysis['clusters'] == 2.0) & (df_analysis['Contract_Month-to-Month'] == 1)].shape[0])
